//
//  AuthResponse.swift
//  AisleDemo
//
//  Created by Gaurav Tiwari on 06/11/24.
//

import Foundation

struct AuthResponse: Decodable {
    let authToken: String?
}
