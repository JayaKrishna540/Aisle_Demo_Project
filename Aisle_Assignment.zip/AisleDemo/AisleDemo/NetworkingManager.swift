//
//  NetworkingManager.swift
//  AisleDemo
//
//  Created by Gaurav Tiwari on 06/11/24.
//

import Foundation
import Combine

class NetworkingManager: ObservableObject {
    @Published var authToken: String = ""
    private var cancellables = Set<AnyCancellable>()
    
    func phoneNumberLogin(phoneNumber: String, completion: @escaping (Bool) -> Void) {
        guard let url = URL(string: "https://app.aisle.co/V1/users/phone_number_login") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = ["number": phoneNumber]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [])
        
        URLSession.shared.dataTaskPublisher(for: request)
            .map(\.data)
            .decode(type: APIResponse.self, decoder: JSONDecoder())
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { _ in }, receiveValue: { response in
                completion(true)
            })
            .store(in: &cancellables)
    }
    
    func verifyOTP(phoneNumber: String, otp: String, completion: @escaping (Bool) -> Void) {
        guard let url = URL(string: "https://app.aisle.co/V1/users/verify_otp") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = ["number": phoneNumber, "otp": otp]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [])
        
        URLSession.shared.dataTaskPublisher(for: request)
            .map(\.data)
            .decode(type: AuthResponse.self, decoder: JSONDecoder())
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { _ in }, receiveValue: { response in
                self.authToken = response.authToken ?? ""
                completion(true)
            })
            .store(in: &cancellables)
    }
    
    func fetchNotes(completion: @escaping ([Note]) -> Void) {
        guard let url = URL(string: "https://app.aisle.co/V1/users/test_profile_list") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(authToken)", forHTTPHeaderField: "Authorization")
        
        URLSession.shared.dataTaskPublisher(for: request)
            .map(\.data)
            .decode(type: NotesResponse.self, decoder: JSONDecoder())
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { _ in }, receiveValue: { response in
                completion(response.notes)
            })
            .store(in: &cancellables)
    }
}



class NetworkingManager2 {
    private var cancellables = Set<AnyCancellable>()
    private var authToken: String?

    

    func verifyOTP(phoneNumber: String, otp: String, completion: @escaping (Bool, String?) -> Void) {
           guard let url = URL(string: "https://app.aisle.co/V1/users/verify_otp") else {
               completion(false, "Invalid URL")
               return
           }
           
           var request = URLRequest(url: url)
           request.httpMethod = "POST"
           request.setValue("application/json", forHTTPHeaderField: "Content-Type")
           
           let body: [String: Any] = ["number": phoneNumber, "otp": otp]
           request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [])
           
           URLSession.shared.dataTaskPublisher(for: request)
               .tryMap { output in
                   guard let response = output.response as? HTTPURLResponse, (200...299).contains(response.statusCode) else {
                       throw URLError(.badServerResponse)
                   }
                   return output.data
               }
               .decode(type: AuthResponse.self, decoder: JSONDecoder())
               .receive(on: DispatchQueue.main)
               .sink(receiveCompletion: { completionStatus in
                   switch completionStatus {
                   case .failure(let error):
                       print("Error:", error)
                       completion(false, error.localizedDescription)
                   case .finished:
                       break
                   }
               }, receiveValue: { response in
                   if let authToken = response.authToken {
                       self.authToken = authToken
                       completion(true, nil) // Verification succeeded
                   } else {
                       completion(false, "Verification failed") // Auth token not provided in response
                   }
               })
               .store(in: &cancellables)
       }
    
    
        func fetchNotes(completion: @escaping ([Note]) -> Void) {
            guard let url = URL(string: "https://app.aisle.co/V1/users/test_profile_list") else { return }
    
            var request = URLRequest(url: url)
            request.httpMethod = "GET"
            request.setValue("Bearer \(String(describing: authToken))", forHTTPHeaderField: "Authorization")
    
            URLSession.shared.dataTaskPublisher(for: request)
                .map(\.data)
                .decode(type: NotesResponse.self, decoder: JSONDecoder())
                .receive(on: DispatchQueue.main)
                .sink(receiveCompletion: { _ in }, receiveValue: { response in
                    completion(response.notes)
                })
                .store(in: &cancellables)
        }
    
//    func fetchNotes(completion: @escaping (Result<[Note], APIError>) -> Void) {
//          guard let authToken = authToken else {
//              completion(.failure(.missingAuthToken))
//              return
//          }
//          
//          guard let url = URL(string: "https://app.aisle.co/V1/users/test_profile_list") else {
//              completion(.failure(.invalidURL))
//              return
//          }
//          
//          var request = URLRequest(url: url)
//          request.httpMethod = "GET"
//          request.setValue("Bearer \(authToken)", forHTTPHeaderField: "Authorization")
//          
//          URLSession.shared.dataTaskPublisher(for: request)
//              .tryMap { output in
//                  guard let response = output.response as? HTTPURLResponse, (200...299).contains(response.statusCode) else {
//                      throw APIError.badServerResponse
//                  }
//                  return output.data
//              }
//              .decode(type: NotesResponse.self, decoder: JSONDecoder())
//              .receive(on: DispatchQueue.main)
//              .sink(receiveCompletion: { completionStatus in
//                  switch completionStatus {
//                  case .failure(let error):
//                      if let apiError = error as? APIError {
//                          completion(.failure(apiError))
//                      } else {
//                          completion(.failure(.customError(error.localizedDescription)))
//                      }
//                  case .finished:
//                      break
//                  }
//              }, receiveValue: { response in
//                  completion(.success(response.notes))
//              })
//              .store(in: &cancellables)
//      }
}
