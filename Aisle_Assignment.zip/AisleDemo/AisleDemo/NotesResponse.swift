//
//  NotesResponse.swift
//  AisleDemo
//
//  Created by Gaurav Tiwari on 06/11/24.
//

import Foundation

struct NotesResponse: Decodable {
    let notes: [Note]
}
