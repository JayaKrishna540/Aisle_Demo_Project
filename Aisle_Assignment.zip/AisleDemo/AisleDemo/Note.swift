//
//  Note.swift
//  AisleDemo
//
//  Created by Gaurav Tiwari on 06/11/24.
//

import Foundation

struct Note: Decodable, Identifiable {
    var id: UUID = UUID() 
    let name: String
    let age: String
    let content: String
}
