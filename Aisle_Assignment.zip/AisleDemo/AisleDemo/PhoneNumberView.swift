//
//  PhoneNumberView.swift
//  AisleDemo
//
//  Created by Gaurav Tiwari on 06/11/24.
//

import SwiftUI

struct PhoneNumberView: View {
    @State private var phoneNumber = ""
    @State private var navigateToOTP = false // State to trigger navigation
    @ObservedObject var networkManager = NetworkingManager()
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Get OTP")
                    .font(.headline)
                
                Text("Enter Your Phone Number")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                HStack {
                    Text("+91")
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(8)
                    
                    TextField("Phone Number", text: $phoneNumber)
                        .keyboardType(.numberPad)
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(8)
                }
                
                Button(action: {
                    networkManager.phoneNumberLogin(phoneNumber: "+91\(phoneNumber)") { success in
                        if success {
                            // If login is successful, trigger navigation
                            navigateToOTP = true
                        }
                    }
                }) {
                    Text("Continue")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.yellow)
                        .cornerRadius(8)
                }
                
                // NavigationLink to OTPView
                NavigationLink(destination: OTPView(networkManager: networkManager), isActive: $navigateToOTP) {
                    EmptyView()
                }
            }
            .padding()
        }
    }
}

