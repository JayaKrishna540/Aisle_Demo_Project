//
//  APIResponse.swift
//  AisleDemo
//
//  Created by Gaurav Tiwari on 06/11/24.
//

import Foundation

//struct APIResponse: Decodable {
//    // Define properties based on API response structure
//}

struct APIResponse: Decodable {
    // Example fields that the response might contain
    let success: Bool
    let message: String?
    let authToken: String?
    let userId: Int?
    let error: String?
    
    enum CodingKeys: String, CodingKey {
        case success
        case message
        case authToken = "auth_token"
        case userId = "user_id"
        case error
    }
}
