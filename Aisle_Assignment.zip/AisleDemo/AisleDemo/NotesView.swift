//
//  NotesView.swift
//  AisleDemo
//
//  Created by Gaurav Tiwari on 06/11/24.
//

import SwiftUI

struct NotesView: View {
    @ObservedObject var networkManager: NetworkingManager
    @State private var notes: [Note] = []
    
    var body: some View {
        VStack {
            Text("Notes")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            List(notes, id: \.id) { note in
                VStack(alignment: .leading) {
                    Text(note.name)
                        .font(.headline)
                    Text(note.age)
                }
            }
        }
        .onAppear {
            networkManager.fetchNotes { fetchedNotes in
                self.notes = fetchedNotes
            }
        }
    }
}

