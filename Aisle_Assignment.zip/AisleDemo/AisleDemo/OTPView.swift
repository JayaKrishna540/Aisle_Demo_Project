//
//  OTPView.swift
//  AisleDemo
//
//  Created by Gaurav Tiwari on 06/11/24.
//

import Foundation
import SwiftUI

struct OTPView: View {
    @State private var otp = ""
    @State private var navigateToNotes = false // State to trigger navigation to Notes screen
    @ObservedObject var networkManager: NetworkingManager
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("+91 9876543212")
                    .font(.subheadline)
                
                Text("Enter The OTP")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                TextField("OTP", text: $otp)
                    .keyboardType(.numberPad)
                    .padding()
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(8)
                
                Button(action: {
                    networkManager.verifyOTP(phoneNumber: "+919876543212", otp: otp) { success in
                        if success {
                            // If OTP is verified successfully, navigate to Notes screen
                            navigateToNotes = true
                        }
                    }
                }) {
                    Text("Continue")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.yellow)
                        .cornerRadius(8)
                }
                
                // Navigation to Notes screen, passing networkManager
                .navigationDestination(isPresented: $navigateToNotes) {
                    NotesView(networkManager: networkManager) // Passing the networkManager
                }
            }
            .padding()
        }
    }
}


