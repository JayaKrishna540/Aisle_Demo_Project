//
//  AisleDemoApp.swift
//  AisleDemo
//
//  Created by Gaurav Tiwari on 06/11/24.
//

import SwiftUI

@main
struct AisleDemoApp: App {
    var body: some Scene {
        WindowGroup {
            PhoneNumberView()
        }
    }
}
