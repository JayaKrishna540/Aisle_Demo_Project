//
//  LikesModel.swift
//  DailyLikesApp
//
//  Created by Gaurav Tiwari on 06/11/24.
//

import Foundation

class LikeManager: ObservableObject {
    @Published var remainingLikes = 10
    @Published var timeToReset = Date()
    
    private var timer: Timer?
    
    func startTimer() {
        // Calculate the next reset time (12:00 PM local time)
        // Update `timeToReset` and set up a timer to update the countdown
    }
    
    func resetLikes() {
        // Reset likes to 10
        remainingLikes = 10
    }
}
