//
//  LikeResetManager.swift
//  DailyLikesApp
//
//  Created by Gaurav Tiwari on 06/11/24.
//

import Foundation
import SwiftUI

/// This class handles the reset of user Likes at 12:00 PM local time.
class LikeResetManager: ObservableObject {
    
    @Published var remainingLikes: Int = 10 // Default starting likes for each day
    @Published var timeToReset: String = ""
    
    private var timer: Timer?
    
    // This will store the user's timezone offset (or this could come from a backend)
    private var userTimeZone: TimeZone = TimeZone.current // Default to the device's current time zone
    
    init() {
        // Initialize the timer when the object is created.
        startResetTimer()
    }
    
    deinit {
        // Invalidate the timer when the object is destroyed.
        timer?.invalidate()
    }
    
    // Start the timer to check the likes reset every minute.
    func startResetTimer() {
        // Calculate the next reset time for 12:00 PM local time
        updateNextResetTime()
        
        // Start a repeating timer that updates the countdown every minute
        timer = Timer.scheduledTimer(withTimeInterval: 60.0, repeats: true) { _ in
            self.checkForLikeReset()
        }
    }
    
    // This function checks if the current time is 12:00 PM local time.
    func checkForLikeReset() {
        let currentDate = Date()
        
        // Compare the current time with the user's 12:00 PM
        let calendar = Calendar.current
        let currentHour = calendar.component(.hour, from: currentDate)
        let currentMinute = calendar.component(.minute, from: currentDate)
        
        // Check if it's time to reset Likes (12:00 PM local time)
        if currentHour == 12 && currentMinute == 0 {
            resetLikes()
        }
        
        // Update the time to reset based on the user's local time zone
        updateNextResetTime()
    }
    
    // This function resets the likes to 10.
    func resetLikes() {
        remainingLikes = 10
        print("Likes have been reset to 10 at 12:00 PM local time.")
    }
    
    // This function calculates the next time the likes should reset (12:00 PM local time).
    func updateNextResetTime() {
        let currentDate = Date()
        let calendar = Calendar.current
        
        // Get the current time in the user's local time zone
        let localTime = calendar.date(bySettingHour: 12, minute: 0, second: 0, of: currentDate)!
        
        // If it's already past 12:00 PM, the next reset is for tomorrow.
        let nextResetTime = localTime > currentDate ? localTime : calendar.date(byAdding: .day, value: 1, to: localTime)!
        
        // Update the time to reset display (formatted for user)
        let dateFormatter = DateFormatter()
        dateFormatter.timeStyle = .short
        dateFormatter.dateStyle = .none
        dateFormatter.timeZone = userTimeZone
        
        // Set the formatted time to show the next reset time.
        timeToReset = dateFormatter.string(from: nextResetTime)
    }
}
