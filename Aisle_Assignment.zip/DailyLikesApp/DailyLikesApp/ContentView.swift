//
//  ContentView.swift
//  DailyLikesApp
//
//  Created by Gaurav Tiwari on 06/11/24.
//

import SwiftUI

import SwiftUI

struct ContentView: View {
    @StateObject private var likeResetManager = LikeResetManager()

    var body: some View {
        NavigationView {
            VStack {
                // Display the remaining Likes
                Text("Remaining Likes: \(likeResetManager.remainingLikes)")
                    .font(.largeTitle)
                    .padding()

                // Display the time until the next reset
                Text("Next reset: \(likeResetManager.timeToReset)")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .padding([.bottom], 30)

                // Countdown Timer View
                CountdownTimerView(nextResetTime: likeResetManager.timeToReset)

                Spacer()
                
                // Optional reset button for testing purposes (removes the need for waiting until the next reset)
                Button(action: {
                    likeResetManager.resetLikes()
                }) {
                    Text("Reset Likes Now")
                        .font(.title2)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding([.top], 20)
            }
            .navigationTitle("Daily Likes")
            .onAppear {
                // Start the reset timer when the view appears
                likeResetManager.startResetTimer()
            }
        }
    }
}


#Preview {
    ContentView()
}
