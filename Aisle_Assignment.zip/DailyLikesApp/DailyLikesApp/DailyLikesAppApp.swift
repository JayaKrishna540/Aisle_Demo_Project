//
//  DailyLikesAppApp.swift
//  DailyLikesApp
//
//  Created by Gaurav Tiwari on 06/11/24.
//

import SwiftUI

@main
struct DailyLikesAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
