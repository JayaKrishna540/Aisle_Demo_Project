//
//  CountdownTimerView.swift
//  DailyLikesApp
//
//  Created by Gaurav Tiwari on 06/11/24.
//

import SwiftUI

struct CountdownTimerView: View {
    let nextResetTime: String
    
    var body: some View {
        VStack {
            Text("Time until next reset:")
                .font(.headline)
                .foregroundColor(.secondary)
            
            // Display the next reset time (12:00 PM) as a formatted string
            Text(nextResetTime)
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(.green)
                .padding()
                .background(Color.yellow.opacity(0.3))
                .cornerRadius(10)
        }
        .padding()
    }
}
